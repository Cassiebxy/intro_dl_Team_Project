#!/usr/bin/env python3
"""Score the packaged 42-case Qwen outputs with the pinned BFCL checker.

No model is loaded. The package contains the exact model inputs, mappings, and
responses selected by exact request signature. Run from any directory:

    python score_and_plot.py
"""
from __future__ import annotations

import csv
import json
import random
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "results"
FIG = ROOT / "figures"
SCORER = ROOT / "scorer"
sys.path.insert(0, str(SCORER))
from evaluate_controlled import score_rows  # noqa: E402

METHODS = ["FLAN-T5-small A1", "FLAN-T5-base multi-cue", "FLAN-T5-base single-cue", "Fixed boundary rules", "BART-base"]
CONDITIONS = ["clean_control", "manipulated", "normalized", "clean_normalized"]
METRICS = ["selected_edited", "selected_original", "edited_argument_correct", "original_argument_correct",
           "edited_cur_correct", "original_cur_correct", "legacy_cr_correct", "strict_overall_correct"]


def read_jsonl(path: Path) -> list[dict]:
    rows = [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines() if s.strip()]
    if not rows:
        raise ValueError(f"Empty JSONL: {path}")
    return rows


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.write_text("".join(json.dumps(r, ensure_ascii=False, allow_nan=False) + "\n" for r in rows), encoding="utf-8")


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty CSV: {path}")
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def summary(rows: list[dict], keys: dict[str, object]) -> dict:
    n = len(rows)
    if n == 0:
        raise ValueError(f"Empty score group: {keys}")
    e_sel = sum(int(r["selected_edited"]) for r in rows)
    o_sel = sum(int(r["selected_original"]) for r in rows)
    e_arg = sum(int(r["edited_argument_correct"]) for r in rows)
    o_arg = sum(int(r["original_argument_correct"]) for r in rows)
    e_cur = sum(int(r["edited_cur_correct"]) for r in rows)
    o_cur = sum(int(r["original_cur_correct"]) for r in rows)
    cr = sum(int(r["legacy_cr_correct"]) for r in rows)
    strict = sum(int(r["strict_overall_correct"]) for r in rows)
    e_rate, o_rate = e_sel / n, o_sel / n
    e_cur_rate, o_cur_rate = e_cur / n, o_cur / n
    result = {
        **keys, "n_requests": n,
        "inference_successes": sum(r["status"] == "ok" for r in rows),
        "parse_failures": sum(r["score_status"] == "parse_error" for r in rows),
        "edited_selected_n": e_sel, "edited_selection_rate": e_rate,
        "original_selected_n": o_sel, "original_selection_rate": o_rate,
        "selection_ratio_edited_over_original": e_rate / o_rate if o_rate else None,
        "edited_arg_correct_given_selected_n": e_arg,
        "edited_argument_accuracy_conditional": e_arg / e_sel if e_sel else None,
        "original_arg_correct_given_selected_n": o_arg,
        "original_argument_accuracy_conditional": o_arg / o_sel if o_sel else None,
        "edited_cur_correct_n": e_cur, "edited_CUR": e_cur_rate,
        "original_cur_correct_n": o_cur, "original_CUR": o_cur_rate,
        "edited_over_original_CUR_ratio": e_cur_rate / o_cur_rate if o_cur_rate else None,
        "absolute_CUR_gap": abs(e_cur_rate - o_cur_rate),
        "legacy_CR_correct_n": cr, "legacy_CR": cr / n,
        "strict_overall_correct_n": strict, "strict_overall_correctness": strict / n,
    }
    return result


def aggregate(scores: list[dict]):
    groupings = [
        (("method", "cue_id", "description_condition"), "summary_by_method_cue_condition.csv"),
        (("method", "description_condition"), "summary_by_method_condition.csv"),
        (("method", "cue_id", "description_condition", "order", "name_mapping"), "summary_by_order_name_cell.csv"),
    ]
    out = {}
    for fields, filename in groupings:
        groups = defaultdict(list)
        for row in scores:
            groups[tuple(row[k] for k in fields)].append(row)
        rows = []
        for key, group in sorted(groups.items(), key=lambda x: str(x[0])):
            labels = dict(zip(fields, key, strict=True))
            rows.append(summary(group, labels))
        write_csv(OUT / filename, rows)
        out[filename] = rows
    # The paper's mitigation objective is cue-specific |CUR_e - CUR_o|.
    # Macro-average those five absolute gaps so opposite cue directions cannot cancel.
    method_condition = out["summary_by_method_condition.csv"]
    cue_rows = out["summary_by_method_cue_condition.csv"]
    for row in method_condition:
        if row["description_condition"] not in {"manipulated", "normalized"}:
            row["mean_absolute_cue_CUR_gap"] = None
            row["cue_count_for_macro_gap"] = 0
            continue
        selected = [x for x in cue_rows if x["method"] == row["method"]
                    and x["description_condition"] == row["description_condition"] and x["cue_id"] != "clean"]
        row["mean_absolute_cue_CUR_gap"] = mean(x["absolute_CUR_gap"] for x in selected)
        row["cue_count_for_macro_gap"] = len(selected)
    write_csv(OUT / "summary_by_method_condition.csv", method_condition)
    return out


def primary_comparisons(scores: list[dict], exclude_overlapping: bool = False) -> list[dict]:
    """Macro cue-wise absolute CUR gaps plus CR preservation, with tool-group bootstrap CIs."""
    chosen = [r for r in scores if not (exclude_overlapping and r.get("query_overlaps_train"))]
    cue_ids = sorted({r["cue_id"] for r in chosen if r["cue_id"] != "clean"})
    rows_out = []
    for method in METHODS:
        subset = [r for r in chosen if r["method"] == method]
        groups = sorted({str(r["source_group_id"]) for r in subset})
        if not groups or len(cue_ids) != 5:
            raise ValueError(f"Unexpected groups/cues in {method}: groups={len(groups)}, cues={cue_ids}")

        def cluster_totals(condition: str):
            # (cue, source_group) -> request count, edited CUR, original CUR, CR
            acc = defaultdict(lambda: [0, 0, 0, 0])
            for r in subset:
                if r["description_condition"] != condition:
                    continue
                key = (r["cue_id"], str(r["source_group_id"]))
                v = acc[key]
                v[0] += 1; v[1] += int(r["edited_cur_correct"]); v[2] += int(r["original_cur_correct"]); v[3] += int(r["legacy_cr_correct"])
            return acc

        totals = {c: cluster_totals(c) for c in ["manipulated", "normalized", "clean_control", "clean_normalized"]}

        def macro_gap(condition: str, draw: list[str] | None = None) -> float:
            gaps = []
            for cue in cue_ids:
                n = e = o = 0
                for group in (draw if draw is not None else groups):
                    c = totals[condition].get((cue, group), [0, 0, 0, 0])
                    n += c[0]; e += c[1]; o += c[2]
                gaps.append(abs(e / n - o / n) if n else float("nan"))
            return mean(gaps)

        def pooled_cr(condition: str, cue: str | None = None, draw: list[str] | None = None) -> float:
            n = cr = 0
            for key_cue in ([cue] if cue else (cue_ids if condition in {"manipulated", "normalized"} else ["clean"])):
                for group in (draw if draw is not None else groups):
                    c = totals[condition].get((key_cue, group), [0, 0, 0, 0])
                    n += c[0]; cr += c[3]
            return cr / n if n else float("nan")

        manip_gap, norm_gap = macro_gap("manipulated"), macro_gap("normalized")
        manip_cr, norm_cr = pooled_cr("manipulated"), pooled_cr("normalized")
        clean_cr, clean_norm_cr = pooled_cr("clean_control"), pooled_cr("clean_normalized")
        rng = random.Random(42042)
        draws = {"manip_gap": [], "norm_gap": [], "reduction": [], "delta_cr": []}
        for _ in range(2000):
            draw = [rng.choice(groups) for __ in range(len(groups))]
            mg, ng = macro_gap("manipulated", draw), macro_gap("normalized", draw)
            draws["manip_gap"].append(mg)
            draws["norm_gap"].append(ng)
            draws["reduction"].append(mg - ng)
            draws["delta_cr"].append(pooled_cr("normalized", draw=draw) - pooled_cr("manipulated", draw=draw))

        def ci(vals):
            v = sorted(vals)
            return v[int(.025 * (len(v) - 1))], v[int(.975 * (len(v) - 1))]

        mg_lo, mg_hi = ci(draws["manip_gap"]); ng_lo, ng_hi = ci(draws["norm_gap"])
        red_lo, red_hi = ci(draws["reduction"]); cr_lo, cr_hi = ci(draws["delta_cr"])
        row = {
            "scope": "sensitivity_exclude_overlap" if exclude_overlapping else "all_42_cases",
            "method": method, "cases": len({r["case_id"] for r in subset}), "source_tool_groups": len(groups),
            "cue_count": len(cue_ids), "requests_manipulated": sum(r["description_condition"] == "manipulated" and r["cue_id"] != "clean" for r in subset),
            "requests_normalized": sum(r["description_condition"] == "normalized" and r["cue_id"] != "clean" for r in subset),
            "manipulated_mean_abs_CUR_gap_pp": 100 * manip_gap,
            "manipulated_gap_CI95_low_pp": 100 * mg_lo, "manipulated_gap_CI95_high_pp": 100 * mg_hi,
            "normalized_mean_abs_CUR_gap_pp": 100 * norm_gap,
            "normalized_gap_CI95_low_pp": 100 * ng_lo, "normalized_gap_CI95_high_pp": 100 * ng_hi,
            "gap_reduction_pp": 100 * (manip_gap - norm_gap),
            "gap_reduction_CI95_low_pp": 100 * red_lo, "gap_reduction_CI95_high_pp": 100 * red_hi,
            "relative_gap_reduction_percent": 100 * (manip_gap - norm_gap) / manip_gap if manip_gap else None,
            "manipulated_CR": manip_cr, "normalized_CR": norm_cr, "normalized_minus_manipulated_CR_pp": 100 * (norm_cr - manip_cr),
            "CR_change_CI95_low_pp": 100 * cr_lo, "CR_change_CI95_high_pp": 100 * cr_hi,
            "clean_control_CR": clean_cr, "clean_through_normalizer_CR": clean_norm_cr,
            "clean_CR_change_pp": 100 * (clean_norm_cr - clean_cr),
            "bootstrap": "2,000 paired cluster resamples of source tool groups; percentile 95% CI; seed 42042",
        }
        rows_out.append(row)
    return rows_out


def paired_effects(scores: list[dict]):
    idx = {}
    for r in scores:
        key = (r["method"], r["case_id"], r["cue_id"], r["order"], r["name_mapping"], r["description_condition"])
        if key in idx:
            raise ValueError(f"Duplicate paired score key: {key}")
        idx[key] = r
    pairs = []
    for method in METHODS:
        for cue in sorted({r["cue_id"] for r in scores if r["method"] == method and r["cue_id"] != "clean"}):
            keys = sorted({(r["case_id"], r["order"], r["name_mapping"])
                           for r in scores if r["method"] == method and r["cue_id"] == cue})
            for case, order, name in keys:
                a = idx[(method, case, cue, order, name, "manipulated")]
                b = idx[(method, case, cue, order, name, "normalized")]
                pairs.append({"method": method, "cue_id": cue, "case_id": case, "order": order,
                              "name_mapping": name, "contrast": "normalized_minus_manipulated",
                              **{f"delta_{m}": int(b[m]) - int(a[m]) for m in METRICS}})
        # Clean-through-normalizer preservation control, once per case/order/name.
        clean_keys = sorted({(r["case_id"], r["order"], r["name_mapping"])
                             for r in scores if r["method"] == method and r["cue_id"] == "clean"})
        for case, order, name in clean_keys:
            a = idx[(method, case, "clean", order, name, "clean_control")]
            b = idx[(method, case, "clean", order, name, "clean_normalized")]
            pairs.append({"method": method, "cue_id": "clean", "case_id": case, "order": order,
                          "name_mapping": name, "contrast": "clean_normalized_minus_clean_control",
                          **{f"delta_{m}": int(b[m]) - int(a[m]) for m in METRICS}})
    write_csv(OUT / "paired_case_effects.csv", pairs)
    groups = defaultdict(list)
    for r in pairs:
        groups[(r["method"], r["cue_id"], r["contrast"])].append(r)
    reduced = []
    for (method, cue, contrast), group in sorted(groups.items()):
        row = {"method": method, "cue_id": cue, "contrast": contrast, "n_paired": len(group)}
        for metric in METRICS:
            values = [x[f"delta_{metric}"] for x in group]
            row[f"mean_delta_{metric}"] = mean(values)
            row[f"improved_n_{metric}"] = sum(v > 0 for v in values)
            row[f"worsened_n_{metric}"] = sum(v < 0 for v in values)
        reduced.append(row)
    write_csv(OUT / "paired_effects_summary.csv", reduced)
    return pairs, reduced


def svg_text(x, y, text, size=14, anchor="middle", fill="#263238", extra=""):
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial,sans-serif" font-size="{size}" fill="{fill}" {extra}>{escape(str(text))}</text>'


def draw_bars(path: Path, title: str, labels: list[str], series: list[tuple[str, list[float], str]], ylabel: str,
              ymax: float, rotate=False):
    W, H = max(1400, 150 * len(labels)), 760
    left, right, top, bottom = 90, W - 40, 110, 625
    plot_h = bottom - top
    plot_w = right - left
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
             '<rect width="100%" height="100%" fill="white"/>', svg_text(W / 2, 46, title, 24, fill="#152935"),
             svg_text(26, (top + bottom) / 2, ylabel, 15, extra=f'transform="rotate(-90 26 {(top+bottom)/2})"')]
    for tick_i in range(6):
        val = ymax * tick_i / 5
        y = bottom - plot_h * val / ymax
        parts.append(f'<line x1="{left}" y1="{y:.1f}" x2="{right}" y2="{y:.1f}" stroke="#dce3e8" stroke-width="1"/>')
        parts.append(svg_text(left - 14, y + 5, f"{val:.0f}%", 12, anchor="end", fill="#52616b"))
    parts.extend([f'<line x1="{left}" y1="{top}" x2="{left}" y2="{bottom}" stroke="#52616b"/>',
                  f'<line x1="{left}" y1="{bottom}" x2="{right}" y2="{bottom}" stroke="#52616b"/>'])
    per_group = plot_w / len(labels)
    bar_w = min(30, per_group / (len(series) + 1))
    for j, (name, values, color) in enumerate(series):
        for i, value in enumerate(values):
            value_pct = value * 100
            cx = left + per_group * (i + 0.5)
            x = cx + (j - (len(series) - 1) / 2) * (bar_w + 4) - bar_w / 2
            h = plot_h * max(0, min(ymax, value_pct)) / ymax
            y = bottom - h
            parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{bar_w:.1f}" height="{h:.1f}" fill="{color}"/>')
            if len(labels) <= 8:
                parts.append(svg_text(x + bar_w / 2, y - 7, f"{value_pct:.1f}", 10, fill="#263238"))
    for i, label in enumerate(labels):
        cx = left + per_group * (i + 0.5)
        if rotate:
            parts.append(f'<text x="{cx:.1f}" y="{bottom+18}" transform="rotate(32 {cx:.1f} {bottom+18})" text-anchor="start" font-family="Arial,sans-serif" font-size="11" fill="#263238">{escape(label)}</text>')
        else:
            parts.append(svg_text(cx, bottom + 23, label, 12, fill="#263238"))
    legend_y = 705
    item_w = W / max(1, len(series))
    for j, (name, _, color) in enumerate(series):
        x = (j + 0.5) * item_w
        parts.append(f'<rect x="{x-58:.1f}" y="{legend_y-13}" width="16" height="16" fill="{color}"/>')
        parts.append(svg_text(x - 34, legend_y, name, 12, anchor="start"))
    parts.append('</svg>')
    path.write_text("\n".join(parts), encoding="utf-8")


def make_figures(summary_tables):
    by_method_condition = {(r["method"], r["description_condition"]): r for r in summary_tables["summary_by_method_condition.csv"]}
    methods_short = {"FLAN-T5-small A1": "FLAN-T5-small A1", "FLAN-T5-base multi-cue": "FLAN-T5-base multi",
                     "FLAN-T5-base single-cue": "FLAN-T5-base single", "Fixed boundary rules": "Rules",
                     "BART-base": "BART-base"}
    labels = [methods_short[m] for m in METHODS]
    manip_gap = [by_method_condition[(m, "manipulated")]["mean_absolute_cue_CUR_gap"] for m in METHODS]
    norm_gap = [by_method_condition[(m, "normalized")]["mean_absolute_cue_CUR_gap"] for m in METHODS]
    draw_bars(FIG / "absolute_CUR_gap_by_method.svg", "Mean cue-wise absolute CUR gap: manipulated vs normalized",
              labels, [("Manipulated", manip_gap, "#d97941"), ("Normalized", norm_gap, "#18858e")],
              "Macro mean absolute CUR gap (%)", 100)
    cond_labels = ["Clean control", "Manipulated", "Normalized", "Clean -> normalized"]
    cond_keys = ["clean_control", "manipulated", "normalized", "clean_normalized"]
    colors = ["#647f96", "#d97941", "#18858e", "#8c73a8"]
    cr_series = [(methods_short[m], [by_method_condition[(m, c)]["legacy_CR"] for c in cond_keys], color)
                 for m, color in zip(METHODS, ["#197c88", "#3973a8", "#8d68a8", "#b36b42", "#4e8b55"], strict=True)]
    # Conditions are represented as separate panels in a compact per-method chart.
    draw_bars(FIG / "CR_by_method_condition.svg", "BFCL correct rate (CR) by method and condition",
              labels, [(c, [by_method_condition[(m, key)]["legacy_CR"] for m in METHODS], color)
                       for c, key, color in zip(cond_labels, cond_keys, colors, strict=True)], "BFCL CR (%)", 100)
    cues = sorted({r["cue_id"] for r in summary_tables["summary_by_method_cue_condition.csv"] if r["cue_id"] != "clean"})
    by_method_cue_condition = {(r["method"], r["cue_id"], r["description_condition"]): r
                               for r in summary_tables["summary_by_method_cue_condition.csv"]}
    cue_labels = [f"{methods_short[m]} / {c}" for m in METHODS for c in cues]
    cue_manip = [by_method_cue_condition[(m, c, "manipulated")]["absolute_CUR_gap"] for m in METHODS for c in cues]
    cue_norm = [by_method_cue_condition[(m, c, "normalized")]["absolute_CUR_gap"] for m in METHODS for c in cues]
    draw_bars(FIG / "absolute_CUR_gap_by_cue.svg", "Absolute CUR gap by cue and normalizer",
              cue_labels, [("Manipulated", cue_manip, "#d97941"), ("Normalized", cue_norm, "#18858e")],
              "Absolute CUR gap (%)", 100, rotate=True)


def main() -> int:
    OUT.mkdir(exist_ok=True)
    FIG.mkdir(exist_ok=True)
    inputs = read_jsonl(DATA / "qwen_inputs.jsonl")
    mappings = read_jsonl(DATA / "qwen_mapping.jsonl")
    raw = read_jsonl(DATA / "raw_responses_reused.jsonl")
    idx_map = {r["experiment_id"]: r for r in mappings}
    if len(idx_map) != len(mappings):
        raise ValueError("Duplicate mapping IDs")
    if {r["experiment_id"] for r in inputs} != set(idx_map):
        raise ValueError("Input and mapping IDs do not match")
    if {r["experiment_id"] for r in raw} != set(idx_map):
        raise ValueError("Every target request must have exactly one reused response")
    if len(raw) != len(idx_map):
        raise ValueError("Duplicate or missing target response IDs")
    method_counts = defaultdict(int)
    case_set = set()
    for r in mappings:
        method_counts[r["normalizer_method"]] += 1
        case_set.add(r["source_case_id"])
        r["cue_id"] = r.get("cue_id") or "clean"
        if r["description_condition"] in {"clean_control", "clean_normalized"}:
            r["cue_id"] = "clean"
    if set(method_counts) != set(METHODS) or any(n != 2016 for n in method_counts.values()):
        raise ValueError(f"Expected 5 methods x 2,016 rows; got {dict(method_counts)}")
    if len(case_set) != 42:
        raise ValueError(f"Expected 42 held-out BFCL cases, found {len(case_set)}")
    if any(r.get("status") != "ok" for r in raw):
        raise ValueError("At least one reused inference failed; inspect raw responses")
    for response in raw:
        m = idx_map[response["experiment_id"]]
        if int(response.get("seed", -1)) != int(m["seed"]):
            raise ValueError(f"Seed mismatch for {response['experiment_id']}")

    scores = score_rows(inputs, mappings, raw, SCORER / "vendor")
    for row in scores:
        m = idx_map[row["experiment_id"]]
        row.update({"method": m["normalizer_method"], "normalizer_method": m["normalizer_method"], "split": "heldout_42",
                    "source_group_id": m.get("source_group_id"), "cue_family": m.get("cue_family"),
                    "slice": m.get("slice"), "query_overlaps_train": m.get("query_overlaps_train")})
        row["cue_id"] = m.get("cue_id") or "clean"
    if len(scores) != 10080:
        raise ValueError(f"Scored row count is {len(scores)}, expected 10,080")
    write_jsonl(OUT / "per_case_bfcl_scores.jsonl", scores)
    csv_scores = [{k: r.get(k) for k in (
        "experiment_id", "normalizer_method", "split", "case_id", "source_group_id", "cue_id", "description_condition",
        "order", "name_mapping", "seed", "status", "score_status", "parsed_call_count", "parse_errors",
        "selected_edited", "selected_original", "edited_argument_correct", "original_argument_correct",
        "edited_cur_correct", "original_cur_correct", "legacy_cr_correct", "strict_overall_correct")}
        for r in scores]
    write_csv(OUT / "per_case_bfcl_scores.csv", csv_scores)
    tables = aggregate(scores)
    pairs, pair_summaries = paired_effects(scores)
    primary = primary_comparisons(scores)
    sensitivity = primary_comparisons(scores, exclude_overlapping=True)
    write_csv(OUT / "primary_comparison_by_method.csv", primary)
    write_csv(OUT / "sensitivity_excluding_overlap.csv", sensitivity)
    make_figures(tables)
    parse_failure_rows = sum(r["score_status"] == "parse_error" for r in scores)
    summary_json = {
        "status": "complete", "scope": "42 held-out BFCL live_simple cases; five normalizer/reference methods",
        "methods": dict(method_counts), "target_requests": len(inputs), "scored_rows": len(scores),
        "unique_cases": len(case_set), "inference_successes": sum(r["status"] == "ok" for r in raw),
        "parse_failures_preserved_in_denominator": parse_failure_rows,
        "missing_responses": 0, "new_gpu_inference_performed": False,
        "primary_metrics": ["edited_CUR", "original_CUR", "edited_over_original_CUR_ratio", "legacy_CR", "absolute_CUR_gap"],
        "secondary_metrics": ["selection_rate", "selection_ratio", "conditional_argument_accuracy", "strict_overall_correctness"],
        "primary_goal": "reduce absolute edited/original CUR gap while preserving CR and clean-through-normalizer performance",
        "strict_overall_convention": "exactly one parsed known tool call, one valid checker diagnostic, no parse/technical error, and no truncation",
    }
    (OUT / "evaluation_status.json").write_text(json.dumps(summary_json, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary_json, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
