# Qwen + BFCL：42 个 held-out 案例的对照评估

这个文件夹是本项目的 **BFCL 工具调用评分与跨方法比较交付包**。它不是之前做的文本相似度/恢复率图，也不是 258 个案例、六种 cue、两种顺序的历史 Table 3 重跑。

## 交付结论

- 范围：42 个 held-out BFCL `live_simple` 案例；5 种 cue；每种 cue 下比较 manipulated 与 normalized，并包含 clean control 和 clean-through-normalizer 对照。
- 方法：FLAN-T5-small A1、FLAN-T5-base multi-cue、FLAN-T5-base single-cue、fixed boundary rules、BART-base。前三个模型系列是 small FLAN-T5、base FLAN-T5、BART；single-cue 和 rules 是 base 方法的消融/参照，不是额外的模型架构。
- 数量：每种方法 2,016 条，合计 10,080 条目标评分行。每种方法都覆盖相同的 42 个案例。
- 评判：用项目固定版本的 BFCL checker 对实际 Qwen 工具调用及参数重新评分；不是用 normalizer 输出的文字相似度代替 BFCL。
- 推理：没有新跑 GPU。10,080 条请求都匹配到已有且成功的 Qwen 响应，匹配依据是完整模型输入/工具定义及实验映射；其中 4,456 条来自历史 7,224 响应档案，5,624 条来自 Person 4 新跑的 1,084 响应。所有目标请求均有且仅有一条响应，成功 10,080，缺失 0。
- Person 4 的 1,084 条新响应与重建出的 42-case 请求逐条核对一致；其已保存评分与本交付包用固定 BFCL checker 重评分结果完全一致（1,084/1,084）。

> 42-case 是 held-out 泛化评估范围，不是历史 baseline 中“六种 cue × 两种顺序”的 12 个条件格。PDF 中历史 Table 3 的 258 × 6 × 2 = 3,096 条请求属于另一阶段。

## 主要结果（BFCL）

主要目标是减小 cue 引起的工具偏好差，同时保持 BFCL CR 与 clean 输入表现。为避免五种 cue 的相反效应相互抵消，主比较先对每种 cue 计算 `|CUR_edited − CUR_original|`，再对五种 cue 等权平均。区间为按 13 个源工具组进行 2,000 次配对 cluster bootstrap 的 percentile 95% CI；样本量较小，因此应作为本项目范围内的估计，而非大规模总体结论。

| 方法 | Manipulated 平均绝对 CUR gap | Normalized 平均绝对 CUR gap | Gap 减少（95% CI） | Manipulated / normalized CR |
|---|---:|---:|---:|---:|
| FLAN-T5-small A1 | 16.19 pp | **3.10 pp** | **13.10 pp** (8.18–27.22) | 66.67% / 66.67% |
| FLAN-T5-base multi-cue | 16.19 pp | 5.00 pp | 11.19 pp (7.32–22.17) | 66.67% / 66.67% |
| FLAN-T5-base single-cue | 16.19 pp | 9.29 pp | 6.90 pp (3.33–17.78) | 66.67% / 66.67% |
| Fixed boundary rules | 16.19 pp | 12.86 pp | 3.33 pp (1.43–8.42) | 66.67% / 66.67% |
| BART-base | 16.19 pp | 6.90 pp | 9.29 pp (4.39–23.04) | 66.67% / 66.67% |

在这 42 个案例上，small A1 的 cue-wise CUR gap 最小；五种方法的 CR 均为 66.67%，clean control 与 clean-through-normalizer 的 CR 也相同。normalized 后的工具选择比率（edited 选择率 / original 选择率）分别为：small A1 1.08、base multi-cue 1.12、base single-cue 1.28、rules 1.41、BART 1.20；manipulated 时为 1.53。选择率仅看选了哪个工具，不要求参数正确；它与 CUR 不可混为一谈。

### 为什么 BFCL CR 完全没有变化？

这是逐条配对后观察到的结果，不是汇总时四舍五入造成的：对每种方法，将同一个 case、cue、工具顺序、名称映射下的 manipulated 与 normalized 请求配对，CR 的 840/840 对成败完全一致（560 对都通过、280 对都失败）。跨条件和方法检查后，每个 case 的 pass/fail 也没有发生变化。

原因在于本实验里的两项工具是同一 BFCL 函数的两个等价副本，函数参数 schema 和预期答案相同，只更改描述、工具名身份或呈现顺序。CUR 会分别问“original 工具有没有被正确调用”和“edited 工具有没有被正确调用”；CR 则只问“至少有一个候选工具是否正确”。因此，如果 normalization 让 Qwen 把调用从 edited 副本改投到 original 副本，CUR 分布/工具选择率会变化，但这个任务仍是成功的，CR 自然不变。反过来，如果某个问题的参数一直生成错误，或者没有产生调用，换描述也可能不改变该问题的 CR。逐条结果还显示，两条件的工具选择分布确实改变，所以“CR 不变”不代表“所有指标都没变化”。

本次每种方法的 CR 为 66.67%（560/840），说明 42-case 样本里 280 个评分请求未被 BFCL 判为任一候选工具正确。CR 适合检查任务成功率是否被描述处理损害；要回答“工具偏好是否减弱”，应看 CUR 差、CUR 比率及独立的工具选择率/selection ratio。不要把 CR 变化作为本实验唯一的效果指标。

这些结果支持“在当前样本和协议下，normalization 与较小的工具偏好差相关，且未观察到 CR 下降”。由于只有 42 个案例、13 个源工具组、每个条件一次推理，且模型 revision 记录为未固定，不能据此声称对所有工具/提示/随机种子普遍有效。排除与训练查询重叠的 1 个案例后，方法排序和 gap 减少方向保持一致；数值见敏感性表。

## 文件说明

- `data/qwen_inputs.jsonl`：10,080 条目标实验的模型输入。
- `data/qwen_mapping.jsonl`：目标 ID 到方法、案例、cue、条件、顺序、名称映射、seed 与源工具组的映射。
- `data/raw_responses_reused.jsonl`：按目标 ID 重新打包的现有 Qwen 原始响应；包含响应来源标记，便于追溯。
- `source_provenance.json`：源文件 SHA-256、响应来源计数、配置兼容性检查和 BFCL 版本信息。
- `scorer/`：固定版本的评分代码及最小 BFCL checker 副本。上游 commit：`05be5f136f00fe66acf0aa853d7bcd44c300946c`。
- `score_and_plot.py`：本地离线评分、汇总和制图入口；不会加载 Qwen，也不会访问 GPU。
- `results/per_case_bfcl_scores.jsonl` / `.csv`：逐请求 BFCL 评分，可用于复查具体案例。
- `results/summary_by_method_cue_condition.csv`：按方法、cue、实验条件汇总。
- `results/summary_by_method_condition.csv`：按方法和条件汇总，含 CUR、CR、选择率、条件参数正确率、严格整体正确率。
- `results/summary_by_order_name_cell.csv`：按顺序和名称映射分层的明细汇总。
- `results/primary_comparison_by_method.csv`：主指标、配对 cluster bootstrap 区间及 CR 保持情况。
- `results/sensitivity_excluding_overlap.csv`：排除训练查询重叠案例后的敏感性结果。
- `results/paired_case_effects.csv`、`paired_effects_summary.csv`：按案例、顺序、名称映射配对的条件变化。
- `results/evaluation_status.json`：覆盖与成功状态机器可读检查。
- `figures/`：三张 SVG 图，可直接插入报告或在浏览器中打开。
- `REPORT_OUTLINE_ZH.md`：可改写进最终报告的 Methods/Results 提纲。

## 指标定义和边界情况

所有请求都留在分母中，包括解析失败、无调用或无效调用；这与“只在成功案例上算准确率”不同。

- **工具选择率**：选中某角色工具的请求数 / 该条件请求总数。选中与参数正确性分开统计。
- **Selection ratio**：edited 工具选择率 / original 工具选择率。original 选择率为 0 时记为未定义（空值），不加平滑常数。
- **Conditional argument accuracy**：在选中对应角色工具的请求中，BFCL checker 判定该角色调用有效的比例。该工具一次也没被选中时记为未定义。多次调用时，某角色只有在被选中且对该角色的所有调用都通过 checker 时才算参数正确。
- **CUR**：该角色工具正确请求数 / 所有该条件请求数。未选中、解析错误、技术错误均不算正确；仍留在总分母中。历史 CUR 定义保持不变。
- **CUR ratio**：`CUR_edited / CUR_original`；original CUR 为 0 时未定义。
- **CUR gap**：主表使用每个 cue 各自的 `|CUR_edited − CUR_original|`，再对 cue 等权宏平均；同时保留每个 cue 的分项表。
- **BFCL CR**：固定 checker 判定 original 或 edited 至少一个角色正确的请求数 / 所有请求数。该项目的历史 CR 定义，不等于强制只允许一条工具调用的准确率。
- **Strict overall correctness（次要）**：只在响应为成功、没有解析错误、恰有一个可解析的已知工具调用、只有一个有效 checker 诊断、checker 通过且生成未因长度上限截断时记为正确。这个额外严格口径不替代 CR。
- **无调用**：两个角色选择率分子均为 0，两个 CUR 均失败，CR 和 strict overall 均失败。
- **未知工具或无效参数**：未知工具不计为任一候选工具选择且 checker 不通过；选中但参数无效会计入选择率，不计入参数正确、CUR 或 CR。
- **多次调用**：选择率按是否至少选择过该角色工具计；角色 CUR 要求它的所有调用都有效；CR 仍按历史“任一角色正确”定义；strict overall 因调用数不等于 1 而失败。
- **解析/技术失败**：保留在总分母中并按失败计；本次 10,080 条中没有技术失败或解析失败。

## 复算

安装 Python 3 后，在本文件夹运行：

```bash
python score_and_plot.py
```

脚本只使用随包提供的输入、映射、响应和 checker，不会启动模型推理。它会覆盖本包内重新生成的 `results/` 与 `figures/` 文件；若要保留当前输出，先复制整个文件夹。

