# 最终报告可用提纲：42-case BFCL 比较

以下文字是按本目录实际评分结果写的报告草稿骨架。正式提交前，团队仍应把模型训练细节、normalizer 训练集/超参数、作者贡献和参考文献统一到总报告中。

## Methods：Held-out BFCL evaluation

我们在 42 个 held-out BFCL `live_simple` 案例上比较五种描述处理方法：FLAN-T5-small A1、FLAN-T5-base multi-cue、FLAN-T5-base single-cue、fixed boundary rules 和 BART-base。每个案例覆盖五种 cue；对每种 cue 分别评估 manipulated 与 normalized 描述，并加入 clean-control 和 clean-through-normalizer 条件。每个条件交叉两种工具呈现顺序及两种工具名称映射，因此每种方法共包含 2,016 个请求，五种方法合计 10,080 个评分行。

所有生成的 Qwen 工具调用均使用 BFCL 项目固定版本 checker 评分。CUR 对每个候选工具分别计算：只有该工具至少被调用一次且该工具的所有调用均通过参数检查，该请求才计为该工具正确；分母为该条件下全部请求。CR 延续历史定义：original 或 edited 至少一个候选工具正确即为正确。另报告选择率、工具选择率比、条件参数正确率及严格单调用整体正确率。主偏好差定义为五种 cue 各自 `|CUR_edited − CUR_original|` 的等权平均，防止不同 cue 的正负偏差相互抵消。95% 区间通过 13 个源工具组的 2,000 次配对 cluster bootstrap 估计，随机种子为 42042。

本次没有重新运行 Qwen。每个目标请求都通过完整序列化模型输入和实验映射匹配至已有成功响应，并保留来源 ID。历史档案提供 4,456 条响应，Person 4 新跑档案提供 5,624 条。匹配前后记录的模型/tokenizer 文件哈希、BF16 精度、生成上限、软件版本、聊天模板及解码设置一致；但 model revision 未固定。Person 4 的 1,084 条新增响应经独立重评分，与其存档评分逐字段相符。

## Results：工具偏好差与 CR

Manipulated 条件的平均 cue-wise 绝对 CUR gap 为 16.19 个百分点，五种方法相同，因为它们使用相同的 manipulated Qwen 响应。Normalization 后，gap 分别为：FLAN-T5-small A1 3.10 pp、FLAN-T5-base multi-cue 5.00 pp、FLAN-T5-base single-cue 9.29 pp、fixed boundary rules 12.86 pp、BART-base 6.90 pp。相对 manipulated 条件的 gap 减少分别为 13.10、11.19、6.90、3.33 和 9.29 pp。各方法 CR 均为 66.67%，clean control 与 clean-through-normalizer 的 CR 也均为 66.67%。

在工具选择率层面，manipulated 条件下 edited/original 选择率比为 1.53；normalized 后该比值为 small A1 1.08、base multi-cue 1.12、base single-cue 1.28、rules 1.41、BART 1.20。选择率反映“选了哪个工具”，CUR 还要求工具调用通过参数检查，两者需分别解释。Small A1 在本样本上得到最低的归一化后偏好差，同时 CR 未见下降；这是一项 held-out 小样本结果，不能据此推断对所有工具组、随机种子或模型版本的普遍表现。

CR 没有变化并非汇总舍入：逐一配对相同 case、cue、顺序和名称映射后，每种方法的 840 对 manipulated/normalized 请求均有完全相同的 CR 成败（560 对正确、280 对错误）。两候选工具是同一函数的等价副本，因此从一个副本改选另一个副本会改变工具偏好相关的 CUR/选择率，却不必改变“至少一个工具调用正确”的 CR。故本结果中 CUR 差与选择率才显示偏好变化；CR 仅说明 normalization 未改变这批请求的任务通过率。

## Robustness and limitations

排除与训练查询重叠的一个案例后，测试范围为 41 个案例；所有方法仍显示较低的 normalized gap，且 CR 与 manipulated 条件相同。该敏感性分析与主分析方向一致。需要报告的限制包括：仅 42 个案例和 13 个源工具组；每个条件一次模型生成，没有跨 seed 置信区间；Qwen 的具体 model revision 未固定；不同 normalizer 训练流程由各方法负责人提供，本文比较的是交付输出在统一下游 Qwen/BFCL 协议下的表现，而非重新训练或保证训练数据完全相同。

## 建议放入正文的表图

1. `results/primary_comparison_by_method.csv`：主结果表，含 gap 减少的 cluster-bootstrap 95% CI、CR 保持情况。
2. `figures/absolute_CUR_gap_by_method.svg`：五种方法在 manipulated 与 normalized 下的平均 cue-wise 绝对 CUR gap。
3. `figures/CR_by_method_condition.svg`：四种条件下各方法的 BFCL CR。
4. `figures/absolute_CUR_gap_by_cue.svg`：每种 cue 的 normalized 前后偏好差，展示方法是否只对部分 cue 有效。
5. 附录可放 `results/summary_by_order_name_cell.csv` 和 `results/per_case_bfcl_scores.csv`，说明顺序与名称映射分层结果及逐例可复核性。

## 汇报时避免混淆

- 这组 42-case 结果回答的是：在同一批 held-out 案例及 Qwen 下游评分协议中，描述处理前后 CUR 偏好差和 BFCL CR 如何变化。
- 不是历史 258-case × 6 cues × 2 orders 的 3,096 请求 baseline 重跑；历史 baseline 是复用响应来源之一。
- “gap 降低”不等于工具调用整体能力提高；本次 CR 不变，说明观察到偏好差缩小的同时，未测得 CR 改变。
- 图上的点估计和区间都受 42 个案例/13 个源工具组的覆盖范围限制。

