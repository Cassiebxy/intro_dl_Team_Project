"""Regenerate handover figures from CSVs; requires matplotlib, no model/network."""
import csv
import pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=pathlib.Path(__file__).resolve().parents[1]
read=lambda name:list(csv.DictReader((root/'tables'/name).open()))
comparison=read('paper_vs_local_table3.csv');orders=read('order_effects.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
settings=[('paper_vs_local_CUR',comparison,
           [('local_edited_CUR_pct','paper_edited_CUR_pct','Edited-tool correct usage'),
            ('local_original_CUR_pct','paper_original_CUR_pct','Original-tool correct usage')],
           ['Our local run','Paper Table 3'],['#197a88','#aab6c2'],
           'Table 3 reproduction: pooled over both tool orders',
           'N = 516 requests per cue; one run; no uncertainty intervals. Paper and local runtimes differ.'),
          ('order_effects',orders,
           [('original_first_edited_CUR_pct','original_first_original_CUR_pct','Original tool first'),
            ('edited_first_edited_CUR_pct','edited_first_original_CUR_pct','Edited tool first')],
           ['Edited role','Original role'],['#197a88','#d78d43'],
           'Strong order dependence in the local baseline',
           'N = 258 per cue/order. Position and tool-name suffix change together; this is not a pure position ablation.')]
for stem,rows,panels,labels,colors,title,note in settings:
    fig,axes=plt.subplots(1,2,figsize=(11,4.7),sharey=True)
    for ax,(a,b,subtitle) in zip(axes,panels):
        ax.bar([i-.175 for i in range(6)],[float(r[a]) for r in rows],.35,label=labels[0],color=colors[0])
        ax.bar([i+.175 for i in range(6)],[float(r[b]) for r in rows],.35,label=labels[1],color=colors[1])
        ax.set_xticks(range(6),[str(i) for i in range(1,7)])
        ax.set_xlabel('Assertive cue ID');ax.set_ylim(0,80);ax.set_title(subtitle)
        ax.set_axisbelow(True);ax.grid(axis='y',alpha=.2)
    axes[0].set_ylabel('CUR (%)')
    fig.suptitle(title,fontweight='bold',y=.99)
    handles,_=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,frameon=False,loc='upper center',bbox_to_anchor=(.5,.92),ncol=2)
    fig.text(.5,.015,note,ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.06,1,.84))
    for suffix in ['png','pdf']:fig.savefig(root/'figures'/f'{stem}.{suffix}',dpi=190,bbox_inches='tight')
    plt.close(fig)
