#!/usr/bin/env python3
"""Portable offline audit. Python >=3.10 standard library only; no model loading."""
import argparse
import collections
import hashlib
import json
import pathlib
import sys

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1])
    parser.add_argument('--output',type=pathlib.Path)
    args=parser.parse_args();root=args.bundle.resolve()
    output=args.output or root/'validation/replay'
    manifest=json.loads((root/'MANIFEST.json').read_text())
    def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
    for name,expected in manifest['files'].items():
        path=(root/name).resolve()
        if not path.is_relative_to(root) or digest(path)!=expected:
            raise ValueError('bundle checksum mismatch: '+name)
    sys.path.insert(0,str(root/'code/src'))
    from table3_baseline.core import (build_requests,read_jsonl,parse_calls,score_response,
                                    summarize,upstream_prompt,_checker)
    snap=root/'evidence/run_snapshot';up=root/'evidence/reference_upstream'
    protocol=json.loads((snap/'protocol.json').read_text())
    for name,expected in protocol['source_hashes'].items():
        if digest(up/name)!=expected:raise ValueError('pinned upstream mismatch: '+name)
    for name,expected in protocol['input_hashes'].items():
        if digest(snap/name)!=expected:raise ValueError('frozen input mismatch: '+name)
    for name,expected in protocol['model_metadata_hashes'].items():
        if digest(root/'evidence/model_metadata'/name)!=expected:raise ValueError('metadata mismatch: '+name)
    cfg=json.loads((snap/'full/run_config.json').read_text())
    if digest(snap/'protocol.json')!=cfg['protocol_sha256']:raise ValueError('protocol/config mismatch')
    for name,expected in cfg['code_hashes'].items():
        if digest(root/'code/src/table3_baseline'/name)!=expected:raise ValueError('run code snapshot mismatch: '+name)
    requests=read_jsonl(snap/'requests.jsonl');raw=read_jsonl(snap/'full/raw_responses.jsonl')
    archived=read_jsonl(snap/'full/scores.jsonl')
    expected=read_jsonl(snap/'expected.jsonl')
    prompts=read_jsonl(snap/'prompts.jsonl')
    if not (len(requests)==len(raw)==len(archived)==len(expected)==len(prompts)==3096):
        raise ValueError('wrong matrix size')
    ids={r['id'] for r in requests}
    if any({r['id'] for r in rows}!=ids for rows in [raw,archived,expected,prompts]):
        raise ValueError('ID alignment mismatch')
    counts=collections.Counter((r['cue_id'],r['order']) for r in requests)
    if len(counts)!=12 or set(counts.values())!={258}:raise ValueError('condition denominator mismatch')
    canonical=read_jsonl(up/'data/BFCL_v3_live_simple.json')
    answers=read_jsonl(up/'data/possible_answer/BFCL_v3_live_simple.json')
    rebuilt=build_requests(canonical,answers)
    frozen={r['id']:r for r in requests};expmap={r['id']:r for r in expected};pmap={r['id']:r for r in prompts}
    for row in rebuilt:
        current=frozen[row['id']]
        if any(current[k]!=v for k,v in row.items()):raise ValueError('request/schema/query/role changed: '+row['id'])
        if expmap[row['id']]['ground_truth']!=row['expected'] or expmap[row['id']]['roles']!=row['roles']:
            raise ValueError('expected mapping changed')
        if upstream_prompt(row,up)!=pmap[row['id']]['text']:raise ValueError('upstream prompt mismatch')
        if hashlib.sha256(pmap[row['id']]['text'].encode()).hexdigest()!=pmap[row['id']]['sha256']:
            raise ValueError('prompt hash mismatch')
    scored=[];parsed_errors=[]
    for response in raw:
        status=response['status'];calls=[]
        if status=='ok':
            try:calls=parse_calls(response['text'])
            except ValueError as error:
                status='parse_error';parsed_errors.append({'id':response['id'],'error':str(error)})
        scored.append(score_response(frozen[response['id']],calls,up,status))
    if scored!=archived:raise ValueError('replayed per-request scores differ from archived scores')
    summary=summarize(requests,scored)
    if summary!=json.loads((snap/'full/summary.json').read_text()):raise ValueError('summary mismatch')
    official=_checker(str(up)).__globals__['ast_checker']
    equivalent=0
    for row,score in [(frozen[s['id']],s) for s in scored if s['calls']]:
        ref=official(row['function'],score['calls'],row['expected'],'Python','live_simple_dup2','Qwen/Qwen2.5-7B-Instruct-FC')
        if bool(ref['valid'])!=score['cr']:raise ValueError('official CR mismatch: '+row['id'])
        for role,name in row['roles'].items():
            if bool(ref.get('validity_per_dup',{}).get(int(name[-1]),False))!=score[role+'_correct']:
                raise ValueError('official per-tool mismatch: '+row['id'])
        equivalent+=1
    # Hand-defined expected behavior, independent of dataset/builder.
    fixture={'id':'test','cue_id':1,'order':'original_first','roles':{'original':'f1','edited':'f2'},
             'function':[{'name':n,'description':'f','parameters':{'type':'dict','required':['x'],'properties':{'x':{'type':'integer','description':'x'}}}} for n in ['f1','f2']],
             'expected':[{'f1':{'x':[7]}},{'f2':{'x':[7]}}]}
    checks=[([],False,False,False),([{'f1':{'x':7}}],True,False,True),
            ([{'f1':{'x':7}},{'f2':{'x':7}}],True,True,True),
            ([{'f1':{'x':7}},{'f1':{'x':8}},{'f2':{'x':7}}],False,True,True),
            ([{'f1':{'x':'7'}}],False,False,False),([{'unknown':{'x':7}}],False,False,False)]
    for calls,a,b,c in checks:
        s=score_response(fixture,calls,up)
        if (s['original_correct'],s['edited_correct'],s['cr'])!=(a,b,c):raise ValueError('metric truth-table failure')
    result={'python_version':sys.version,'manifest_sha256':digest(root/'MANIFEST.json'),
            'checksums_pass':True,'source_input_prompt_checks_pass':True,'requests':3096,'unique_response_ids':len(ids),
            'conditions':12,'per_condition_denominator':258,'per_cue_denominator':516,
            'per_request_scores_equal':True,'summaries_equal':True,'official_nonempty_call_scores_equal':equivalent,
            'metric_truth_table_cases':len(checks),'parse_failures':parsed_errors,
            'model_loaded':False,'network_used':False,'teammate_independent_signoff':'PENDING'}
    output.mkdir(parents=True,exist_ok=True)
    (output/'verification_result.json').write_text(json.dumps(result,indent=2)+'\n')
    (output/'replayed_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (output/'replayed_scores.jsonl').write_text(''.join(json.dumps(s,ensure_ascii=False)+'\n' for s in scored))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
