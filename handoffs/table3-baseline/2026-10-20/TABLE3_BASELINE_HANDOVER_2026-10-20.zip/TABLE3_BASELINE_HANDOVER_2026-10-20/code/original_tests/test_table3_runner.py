import json
import pytest
from table3_baseline.runner import output_budget, validate_resume, choose_smoke, validate_smoke_config, attempt_state

def test_budget_matches_upstream_and_rejects_overflow():
    assert output_budget(100,32768)==4096
    assert output_budget(32000,32768)==766
    with pytest.raises(ValueError):output_budget(32767,32768)

def test_resume_rejects_config_drift_and_duplicate_results(tmp_path):
    p=tmp_path/'run';p.mkdir()
    config={'model_revision':'abc','requests_sha256':'def'}
    assert validate_resume(p,config)==set()
    (p/'run_config.json').write_text(json.dumps(config))
    (p/'raw_responses.jsonl').write_text('{"id":"one"}\n')
    assert validate_resume(p,config)=={'one'}
    with pytest.raises(ValueError,match='config'):
        validate_resume(p,{**config,'model_revision':'changed'})
    (p/'raw_responses.jsonl').write_text('{"id":"one"}\n{"id":"one"}\n')
    with pytest.raises(ValueError,match='duplicate'):validate_resume(p,config)

def test_smoke_is_cue6_both_orders_and_length_diverse():
    rows=[{'id':str(i),'cue_id':6,'case_id':str(i//2),'order':['original_first','edited_first'][i%2], 'prompt_tokens':i//2+1} for i in range(516)]
    rows.append({'id':'exclude','cue_id':1,'case_id':'x','order':'original_first','prompt_tokens':1})
    chosen=choose_smoke(rows,10)
    assert len(chosen)==20
    assert {r['cue_id'] for r in chosen}=={6}
    assert {r['order'] for r in chosen}=={'original_first','edited_first'}
    assert {'0','257'} <= {r['case_id'] for r in chosen}

def test_full_gate_rejects_smoke_from_changed_code_or_environment(tmp_path):
    smoke=tmp_path/'smoke';smoke.mkdir()
    original={'phase':'smoke','protocol_sha256':'a','code_hashes':{'runner.py':'b'},'packages':{'torch':'2.9.1'}}
    (smoke/'run_config.json').write_text(json.dumps(original))
    validate_smoke_config(smoke,{**original,'phase':'full'})
    with pytest.raises(ValueError,match='config'):
        validate_smoke_config(smoke,{**original,'phase':'full','code_hashes':{'runner.py':'changed'}})

def test_interrupted_attempts_consume_budget_and_success_is_recoverable(tmp_path):
    log=tmp_path/'attempts.jsonl'
    log.write_text('\n'.join(json.dumps(x) for x in [
        {'id':'a','attempt':1,'status':'started'},
        {'id':'a','attempt':1,'status':'technical_error'},
        {'id':'a','attempt':2,'status':'started'},
        {'id':'b','attempt':1,'status':'started'},
        {'id':'b','attempt':1,'status':'ok','response':{'id':'b','text':'saved'}},
    ])+'\n')
    state=attempt_state(log)
    assert state['a']['used']==2 and state['a']['response'] is None
    assert state['b']['used']==1 and state['b']['response']['text']=='saved'
