import json
from pathlib import Path
from table3_baseline.core import build_requests,write_jsonl
from table3_baseline.runner import replay

UPSTREAM=Path('/Users/cathybao/Documents/Projects/Team_Project_dl/references/upstream/llm-unreliable-tool-preferences')

def test_replay_retains_failed_and_missing_cases_and_is_repeatable(tmp_path):
    case={'id':'live_simple_fixture','question':[[{'role':'user','content':'Get 7'}]],
          'function':[{'name':'get','description':'Get.',
          'parameters':{'type':'dict','required':['id'],'properties':{'id':{'type':'integer','description':'ID'}}}}]}
    answer={'id':case['id'],'ground_truth':[{'get':{'id':[7]}}]}
    rows=build_requests([case],[answer])
    write_jsonl(tmp_path/'requests.jsonl',rows)
    (tmp_path/'protocol.json').write_text(json.dumps({'input_hashes':{},'source_hashes':{},'model_metadata_hashes':{},
        'upstream_path':str(UPSTREAM),'differences':['test fixture only']}))
    out=tmp_path/'full';out.mkdir()
    write_jsonl(out/'raw_responses.jsonl',[
        {'id':rows[0]['id'],'status':'ok','text':'<tool_call>\n{"name":"get2","arguments":{"id":7}}\n</tool_call>',
         'elapsed_seconds':1,'finish_reason':'stop'},
        {'id':rows[1]['id'],'status':'technical_error','text':'','elapsed_seconds':1},
        {'id':rows[2]['id'],'status':'ok','text':'<tool_call>\ninvalid\n</tool_call>',
         'elapsed_seconds':1,'finish_reason':'stop'},
    ])
    status=replay(tmp_path,'full')
    assert status['complete'] is False and status['completed']==3 and status['expected']==12
    assert status['technical_failures']==1 and status['parse_failures']==1
    summary=json.loads((out/'summary.json').read_text())
    assert summary[0]['edited_cur']==0.5 and summary[0]['denominator']==2
    assert summary[2]['missing']==2 and summary[2]['denominator']==2
    saved=(out/'scores.jsonl').read_bytes()
    assert replay(tmp_path,'full')==status
    assert (out/'scores.jsonl').read_bytes()==saved
