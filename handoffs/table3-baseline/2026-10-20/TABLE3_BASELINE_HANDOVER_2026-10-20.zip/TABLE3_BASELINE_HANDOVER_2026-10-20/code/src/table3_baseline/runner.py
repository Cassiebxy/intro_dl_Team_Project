"""Prepare, run and replay a frozen Table 3 experiment on Mac GPU."""
import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
import platform
import statistics
import subprocess
import time
from pathlib import Path
from .core import (CUES, MODEL, PAPER, UPSTREAM_COMMIT, build_requests,
                   parse_calls, read_jsonl, score_response, sha256, summarize,
                   upstream_prompt, write_jsonl)

def dump(path,value):
    temp=Path(str(path)+'.tmp')
    temp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    temp.replace(path)

def append(path,value):
    with Path(path).open('a') as f:
        f.write(json.dumps(value,ensure_ascii=False,allow_nan=False)+'\n')
        f.flush();os.fsync(f.fileno())

def output_budget(input_tokens,context):
    if input_tokens+2>context:raise ValueError('prompt exceeds context budget')
    return min(4096,context-input_tokens-2)

def validate_resume(path,config):
    path=Path(path)
    saved=path/'run_config.json'
    if saved.exists() and json.loads(saved.read_text())!=config:
        raise ValueError('run config changed; use a new run directory')
    raw=path/'raw_responses.jsonl'
    if raw.exists() and not saved.exists():raise ValueError('raw results without config')
    return {r['id'] for r in read_jsonl(raw)} if raw.exists() else set()

def validate_smoke_config(path,full_config):
    path=Path(path)
    if not (path/'run_config.json').exists():raise ValueError('missing smoke config')
    validate_resume(path,{**full_config,'phase':'smoke'})

def attempt_state(path):
    path=Path(path)
    states={}
    if not path.exists():return states
    for line in path.read_text().splitlines():
        row=json.loads(line)
        state=states.setdefault(row['id'],{'used':0,'response':None})
        state['used']=max(state['used'],row['attempt'])
        if row['status']=='ok':state['response']=row['response']
    return states

def choose_smoke(rows,n_cases):
    by_case={}
    for row in rows:
        if row['cue_id']==6:by_case.setdefault(row['case_id'],[]).append(row)
    cases=sorted(by_case,key=lambda k:max(r['prompt_tokens'] for r in by_case[k]))
    if n_cases<2 or n_cases>len(cases):raise ValueError('invalid smoke case count')
    indices=[round(i*(len(cases)-1)/(n_cases-1)) for i in range(n_cases)]
    return [r for i in indices for r in by_case[cases[i]]]

def code_hashes():
    return {p.name:sha256(p) for p in Path(__file__).parent.glob('*.py')}

def prepare(root,upstream,model_path):
    from transformers import AutoTokenizer,AutoConfig
    root=Path(root);upstream=Path(upstream);model_path=Path(model_path)
    if (root/'protocol.json').exists():raise ValueError('protocol exists; never overwrite frozen inputs')
    revision=json.loads((root/'model_revision.json').read_text())['revision']
    actual=subprocess.check_output(['git','-C',str(upstream),'rev-parse','HEAD'],text=True).strip()
    if actual!=UPSTREAM_COMMIT:raise ValueError('upstream commit changed')
    source=upstream/'data/BFCL_v3_live_simple.json'
    answers=upstream/'data/possible_answer/BFCL_v3_live_simple.json'
    cases=read_jsonl(source)
    if len(cases)!=258:raise ValueError('Table 3 requires 258 cases')
    rows=build_requests(cases,read_jsonl(answers))
    tokenizer=AutoTokenizer.from_pretrained(model_path,local_files_only=True)
    config=AutoConfig.from_pretrained(model_path,local_files_only=True)
    prompts=[]
    for row in rows:
        prompt=upstream_prompt(row,upstream)
        tokens=tokenizer.encode(prompt,add_special_tokens=True)
        row['prompt_tokens']=len(tokens)
        row['max_new_tokens']=output_budget(len(tokens),config.max_position_embeddings)
        prompts.append({'id':row['id'],'text':prompt,'sha256':hashlib.sha256(prompt.encode()).hexdigest()})
    write_jsonl(root/'requests.jsonl',rows)
    write_jsonl(root/'expected.jsonl',[{'id':r['id'],'roles':r['roles'],'ground_truth':r['expected']} for r in rows])
    write_jsonl(root/'prompts.jsonl',prompts)
    write_jsonl(root/'smoke_requests.jsonl',choose_smoke(rows,10))
    files=['data/BFCL_v3_live_simple.json','data/possible_answer/BFCL_v3_live_simple.json',
           'bfcl/model_handler/local_inference/qwen_fc.py','bfcl/model_handler/utils.py',
           'bfcl/eval_checker/ast_eval/ast_checker.py','bfcl/constants/eval_config.py',
           'bfcl/constants/type_mappings.py','bfcl/eval_checker/ast_eval/type_convertor/java_type_converter.py',
           'bfcl/eval_checker/ast_eval/type_convertor/js_type_converter.py']
    protocol={'model':MODEL,'model_revision':revision,'upstream_commit':actual,'upstream_path':str(upstream),
        'model_path':str(model_path),'source_hashes':{p:sha256(upstream/p) for p in files},
        'model_metadata_hashes':{p.name:sha256(p) for p in model_path.glob('*.json')},
        'input_hashes':{p:sha256(root/p) for p in ['requests.jsonl','expected.jsonl','prompts.jsonl','smoke_requests.jsonl']},
        'case_ids':[r['id'] for r in cases],'request_count':len(rows),'cues':CUES,
        'context':config.max_position_embeddings,'dtype':'bfloat16','backend':'transformers-mps','attention':'sdpa',
        'temperature_requested_upstream':0.001,'temperature_effective':0.01,
        'temperature_note':'vLLM 0.7.3 SamplingParams clamps 0 < temperature < 0.01 to 0.01; mirror effective behavior.',
        'generation':{'do_sample':True,'temperature':0.01,'top_p':1.0,'top_k':0,'repetition_penalty':1.0},
        'seed_policy':'SHA256(request ID) first 8 hex digits modulo 2^31; stable across resume; upstream seed unspecified',
        'max_output':'min(4096, context - input_tokens - 2)','retry_policy':'technical failures only, maximum 2 retries; same per-case seed',
        'differences':['Apple MPS/Transformers instead of CUDA/vLLM 0.7.3','BF16 hardware numerics and sampling RNG differ',
                       'Explicit stable per-request seeds; original run seeds not documented',
                       'Safe literal parsing instead of upstream eval fallback; invalid calls retained as failures',
                       'Original publication checkpoint revision unknown; current official revision frozen'],
        'prompt_tokens':{'min':min(r['prompt_tokens'] for r in rows),'median':statistics.median(r['prompt_tokens'] for r in rows),
                         'max':max(r['prompt_tokens'] for r in rows)}}
    dump(root/'protocol.json',protocol)
    print(json.dumps({'prepared':len(rows),'smoke':20,'prompt_tokens':protocol['prompt_tokens']}),flush=True)

def check_frozen(root,protocol):
    for name,digest in protocol['input_hashes'].items():
        if sha256(root/name)!=digest:raise ValueError(f'frozen input changed: {name}')
    for name,digest in protocol['source_hashes'].items():
        if sha256(Path(protocol['upstream_path'])/name)!=digest:raise ValueError(f'upstream file changed: {name}')
    for name,digest in protocol['model_metadata_hashes'].items():
        if sha256(Path(protocol['model_path'])/name)!=digest:raise ValueError(f'model metadata changed: {name}')

def replay(root,phase):
    root=Path(root);protocol=json.loads((root/'protocol.json').read_text());check_frozen(root,protocol)
    rows=read_jsonl(root/('smoke_requests.jsonl' if phase=='smoke' else 'requests.jsonl'))
    out=root/phase
    raw=read_jsonl(out/'raw_responses.jsonl') if (out/'raw_responses.jsonl').exists() else []
    mapping={r['id']:r for r in rows}
    scores=[]
    for response in raw:
        if response['id'] not in mapping:raise ValueError('unexpected response ID')
        status=response['status'];calls=[]
        if status=='ok':
            try:calls=parse_calls(response['text'])
            except ValueError:status='parse_error'
        scores.append(score_response(mapping[response['id']],calls,protocol['upstream_path'],status))
    summary=summarize(rows,scores)
    orders=[]
    for order in ['original_first','edited_first']:
        orders.extend(dict(s,order=order) for s in summarize([r for r in rows if r['order']==order],[s for s in scores if s['order']==order]))
    # Derived artifacts are safe to replace: raw responses are append-only.
    temp=out/'scores.replay.tmp'
    if temp.exists():temp.unlink()
    write_jsonl(temp,scores);temp.replace(out/'scores.jsonl')
    for filename,records in [('baseline_table3_results.csv',summary),('results_by_order.csv',orders)]:
        with (out/filename).open('w') as f:
            writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    dump(out/'summary.json',summary)
    durations=[r['elapsed_seconds'] for r in raw if r['status']=='ok']
    elapsed=sum(durations)
    complete=len(raw)==len(rows)
    stats={'phase':phase,'complete':complete,'completed':len(raw),'expected':len(rows),
           'technical_failures':sum(r['status']=='technical_error' for r in raw),
           'parse_failures':sum(s['status']=='parse_error' for s in scores),
           'length_finishes':sum(r.get('finish_reason')=='length' for r in raw),
           'seconds_per_request':elapsed/len(durations) if durations else None,
           'full_run_hours_at_measured_rate':elapsed/len(durations)*3096/3600 if durations else None}
    dump(out/'status.json',stats)
    lines=['# Table 3 Qwen2.5-7B local baseline', '',f"Phase: {phase}; completed {len(raw)}/{len(rows)}. Complete: {complete}.",
           '', 'Paper values are references, not new results. Missing/technical/parse failures remain in denominators.',
           '', '| cue | edited CUR | original CUR | ratio | CR | paper edited / original / ratio / CR |',
           '|---|---:|---:|---:|---:|---|']
    for s in summary:
        ratio=f"{s['ratio']:.3f}" if s['ratio'] is not None else 'undefined'
        paper=PAPER[s['cue_id']-1]
        lines.append(f"| {s['cue_id']} | {s['edited_cur']:.2%} | {s['original_cur']:.2%} | {ratio} | {s['cr']:.2%} | {paper} |")
    lines+=['','## Runtime and completeness','',json.dumps(stats,indent=2),'','## Differences from original environment','']
    lines+=['- '+s for s in protocol['differences']]
    if phase=='full' and complete:
        favored=sum(s['edited_cur']>s['original_cur'] for s in summary)
        lines+=['','## Comparison','',f'Edited-tool CUR exceeds original-tool CUR in {favored}/{len(summary)} cue conditions.',
                'The table below reports local minus paper values in percentage points. A single run and a backend change do not establish statistical equivalence.',
                '', '| cue | edited CUR delta (pp) | original CUR delta (pp) | CR delta (pp) |',
                '|---|---:|---:|---:|']
        for s in summary:
            p=PAPER[s['cue_id']-1]
            lines.append(f"| {s['cue_id']} | {100*s['edited_cur']-p[0]:+.2f} | {100*s['original_cur']-p[1]:+.2f} | {100*s['cr']-p[3]:+.2f} |")
        lines+=['','Position effects are reported separately in results_by_order.csv; each order has 258 cases per cue. CUR values can overlap because both tools may be correctly used in one response.']
    lines+=['','Paper reference: https://aclanthology.org/2025.emnlp-main.1060.pdf (Table 3).',
            'Environment: '+str(protocol.get('backend','fixture'))+'; dtype '+str(protocol.get('dtype','fixture'))+
            '; checkpoint revision '+str(protocol.get('model_revision','fixture'))+'.']
    lines+=['','## Replay','', 'Run the saved replay command from LOCAL_BASELINE_README.md. Replays use raw_responses.jsonl and do not load a model.',
            '', 'The smoke subset is length-stratified and is not an estimate of full-dataset accuracy.']
    (out/'BASELINE_REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(stats),flush=True)
    return stats

def run(root,phase):
    import torch
    from transformers import AutoTokenizer,AutoModelForCausalLM,GenerationConfig
    root=Path(root);protocol=json.loads((root/'protocol.json').read_text());check_frozen(root,protocol)
    if not torch.backends.mps.is_available():raise RuntimeError('MPS unavailable; refusing CPU fallback')
    rows=read_jsonl(root/('smoke_requests.jsonl' if phase=='smoke' else 'requests.jsonl'))
    prompts={r['id']:r['text'] for r in read_jsonl(root/'prompts.jsonl')}
    out=root/phase;out.mkdir(exist_ok=True)
    # Prevent concurrent runners writing the same append-only output.
    import fcntl
    with (out/'runner.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        config={'protocol_sha256':sha256(root/'protocol.json'),'phase':phase,'code_hashes':code_hashes(),
                'packages':{p:importlib.metadata.version(p) for p in ['torch','transformers','numpy','tokenizers']},
                'python':platform.python_version(),'platform':platform.platform()}
        if phase=='full':
            validate_smoke_config(root/'smoke',config)
            gate=replay(root,'smoke')
            if not gate['complete'] or gate['technical_failures'] or gate['length_finishes'] or gate['parse_failures']:
                raise ValueError('smoke gate not passed; inspect outputs before full run')
        done=validate_resume(out,config)
        if done-{r['id'] for r in rows}:raise ValueError('unexpected completed IDs')
        if not (out/'run_config.json').exists():dump(out/'run_config.json',config)
        pending=[r for r in rows if r['id'] not in done]
        if not pending:return replay(root,phase)
        tokenizer=AutoTokenizer.from_pretrained(protocol['model_path'],local_files_only=True)
        print(f'Loading model for {phase}; {len(pending)} pending',flush=True)
        start=time.monotonic()
        model=AutoModelForCausalLM.from_pretrained(protocol['model_path'],local_files_only=True,
            torch_dtype=torch.bfloat16,attn_implementation=protocol['attention']).to('mps').eval()
        eos=json.loads((Path(protocol['model_path'])/'generation_config.json').read_text())['eos_token_id']
        gen=GenerationConfig(**protocol['generation'],eos_token_id=eos,pad_token_id=tokenizer.pad_token_id,
                             bos_token_id=tokenizer.bos_token_id,use_cache=True)
        dump(out/'generation_config.json',gen.to_dict())
        print(f'Model loaded in {time.monotonic()-start:.1f}s; allocated GB {torch.mps.current_allocated_memory()/1e9:.2f}',flush=True)
        history=attempt_state(out/'attempts.jsonl')
        for row in pending:
            state=history.get(row['id'],{'used':0,'response':None})
            if state['response'] is not None:
                append(out/'raw_responses.jsonl',state['response'])
                done.add(row['id'])
                continue
            if state['used']>=3:
                response={'id':row['id'],'status':'technical_error','text':'','elapsed_seconds':0,
                          'attempt':state['used'],'error':'attempt budget exhausted before interrupted run resumed'}
                append(out/'raw_responses.jsonl',response)
                replay(root,phase)
                raise RuntimeError('attempt budget exhausted; stop for diagnosis')
            inputs=tokenizer(prompts[row['id']],return_tensors='pt',add_special_tokens=True).to('mps')
            if inputs.input_ids.shape[1]!=row['prompt_tokens']:raise ValueError('tokenizer drift')
            seed=int(hashlib.sha256(row['id'].encode()).hexdigest()[:8],16)%(2**31)
            response=None
            for attempt in range(state['used']+1,4):
                append(out/'attempts.jsonl',{'id':row['id'],'attempt':attempt,'status':'started'})
                torch.manual_seed(seed);torch.mps.manual_seed(seed)
                tick=time.monotonic()
                try:
                    with torch.inference_mode():
                        generated=model.generate(**inputs,generation_config=gen,max_new_tokens=row['max_new_tokens'])
                    torch.mps.synchronize()
                    ids=generated[0,inputs.input_ids.shape[1]:].cpu().tolist()
                    text=tokenizer.decode(ids,skip_special_tokens=True,clean_up_tokenization_spaces=False)
                    response={'id':row['id'],'status':'ok','text':text,'output_token_ids':ids,'input_tokens':row['prompt_tokens'],
                        'output_tokens':len(ids),'elapsed_seconds':time.monotonic()-tick,'attempt':attempt,'seed':seed,
                        'finish_reason':'stop' if ids and ids[-1] in eos else 'length',
                        'allocated_memory_gb':torch.mps.current_allocated_memory()/1e9}
                    append(out/'attempts.jsonl',{'id':row['id'],'attempt':attempt,'status':'ok','response':response})
                    break
                except RuntimeError as exc:
                    append(out/'attempts.jsonl',{'id':row['id'],'attempt':attempt,'status':'technical_error','error':str(exc)})
                    torch.mps.empty_cache()
                    if attempt==3:
                        response={'id':row['id'],'status':'technical_error','text':'','error':str(exc),
                                  'elapsed_seconds':time.monotonic()-tick,'attempt':attempt,'seed':seed}
            append(out/'raw_responses.jsonl',response)
            done.add(row['id'])
            print(json.dumps({'completed':len(done),'total':len(rows),'id':row['id'],'seconds':round(response['elapsed_seconds'],2),
                              'tokens':response.get('output_tokens'),'status':response['status']}),flush=True)
            dump(out/'live_status.json',{'completed':len(done),'total':len(rows),'last_id':row['id'],'updated_unix':time.time()})
            if response['status']=='technical_error':
                replay(root,phase)
                raise RuntimeError('technical failure persisted through two retries; stop for diagnosis')
        return replay(root,phase)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','run','replay'])
    parser.add_argument('--root',required=True,type=Path)
    parser.add_argument('--upstream',type=Path)
    parser.add_argument('--model-path',type=Path)
    parser.add_argument('--phase',choices=['smoke','full'],default='smoke')
    args=parser.parse_args()
    if args.action=='prepare':prepare(args.root,args.upstream,args.model_path)
    elif args.action=='run':run(args.root,args.phase)
    else:replay(args.root,args.phase)

if __name__=='__main__':main()
