"""Bounded local reproduction of Table 3, Qwen2.5-7B only."""
