"""Continue the authorized local baseline through fixed acceptance gates."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args();root=args.root
    repo=Path(__file__).resolve().parent
    def status(phase,**extra):
        value={'phase':phase,'updated_unix':time.time(),**extra}
        temp=root/'pipeline_status.tmp'
        temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(root/'pipeline_status.json')
        print(json.dumps(value),flush=True)
    with (root/'pipeline.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            status('waiting_for_model_download')
            deadline=time.monotonic()+3*3600
            while not (root/'model_path.txt').exists():
                if time.monotonic()>deadline:raise TimeoutError('model download marker absent after 3h; inspect download')
                time.sleep(10)
            model=Path((root/'model_path.txt').read_text().strip())
            status('verifying_model_weights')
            index=json.loads((model/'model.safetensors.index.json').read_text())
            weights={}
            for name in sorted(set(index['weight_map'].values())):
                path=model/name
                digest=hashlib.sha256()
                with path.open('rb') as f:
                    for chunk in iter(lambda:f.read(8*1024*1024),b''):digest.update(chunk)
                checksum=digest.hexdigest()
                if path.resolve().name!=checksum:raise ValueError(f'weight SHA256 mismatch {name}')
                weights[name]={'sha256':checksum,'bytes':path.stat().st_size}
            (root/'weights_manifest.json').write_text(json.dumps(weights,indent=2)+'\n')
            env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(repo/'src'),
                 'TOKENIZERS_PARALLELISM':'false','HF_HUB_OFFLINE':'1'}
            command=[sys.executable,'-u','-m','table3_baseline.runner']
            def invoke(action,phase):
                with (root/f'{phase}_execution.log').open('a') as log:
                    result=subprocess.run(command+[action,'--root',str(root),'--phase',phase],cwd=repo,env=env,
                                          stdout=log,stderr=subprocess.STDOUT)
                if result.returncode:raise RuntimeError(f'{phase} {action} failed, inspect {phase}_execution.log')
            status('smoke_running',requests=20)
            invoke('run','smoke')
            gate=json.loads((root/'smoke/status.json').read_text())
            if not gate['complete'] or gate['technical_failures'] or gate['parse_failures'] or gate['length_finishes']:
                raise RuntimeError('smoke acceptance failed; inspect saved raw responses')
            status('full_running',requests=3096,smoke_seconds_per_request=gate['seconds_per_request'],
                   estimated_full_hours=gate['full_run_hours_at_measured_rate'])
            invoke('run','full')
            first=(root/'full/scores.jsonl').read_bytes()
            invoke('replay','full')
            if (root/'full/scores.jsonl').read_bytes()!=first:raise ValueError('offline replay is not identical')
            result=json.loads((root/'full/status.json').read_text())
            if not result['complete'] or result['completed']!=3096:raise ValueError('full matrix incomplete')
            status('complete',result=result,report=str(root/'full/BASELINE_REPORT.md'),
                   scores_replayed_identically=True)
        except BaseException as exc:
            status('needs_attention',error=f'{type(exc).__name__}: {exc}')
            raise

if __name__=='__main__':main()
