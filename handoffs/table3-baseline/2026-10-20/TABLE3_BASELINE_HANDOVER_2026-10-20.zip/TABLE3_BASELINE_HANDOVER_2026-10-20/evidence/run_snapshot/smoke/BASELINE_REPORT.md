# Table 3 Qwen2.5-7B local baseline

Phase: smoke; completed 20/20. Complete: True.

Paper values are references, not new results. Missing/technical/parse failures remain in denominators.

| cue | edited CUR | original CUR | ratio | CR | paper edited / original / ratio / CR |
|---|---:|---:|---:|---:|---|
| 6 | 60.00% | 10.00% | 6.000 | 70.00% | (66.9, 8.5, 7.84, 75.4) |

## Runtime and completeness

{
  "phase": "smoke",
  "complete": true,
  "completed": 20,
  "expected": 20,
  "technical_failures": 0,
  "parse_failures": 0,
  "length_finishes": 0,
  "seconds_per_request": 4.256966985494364,
  "full_run_hours_at_measured_rate": 3.6609916075251525
}

## Differences from original environment

- Apple MPS/Transformers instead of CUDA/vLLM 0.7.3
- BF16 hardware numerics and sampling RNG differ
- Explicit stable per-request seeds; original run seeds not documented
- Safe literal parsing instead of upstream eval fallback; invalid calls retained as failures
- Original publication checkpoint revision unknown; current official revision frozen

Paper reference: https://aclanthology.org/2025.emnlp-main.1060.pdf (Table 3).
Environment: transformers-mps; dtype bfloat16; checkpoint revision a09a35458c702b33eeacc393d103063234e8bc28.

## Replay

Run the saved replay command from LOCAL_BASELINE_README.md. Replays use raw_responses.jsonl and do not load a model.

The smoke subset is length-stratified and is not an estimate of full-dataset accuracy.
