# Table 3 Qwen2.5-7B local baseline

Phase: full; completed 3096/3096. Complete: True.

Paper values are references, not new results. Missing/technical/parse failures remain in denominators.

| cue | edited CUR | original CUR | ratio | CR | paper edited / original / ratio / CR |
|---|---:|---:|---:|---:|---|
| 1 | 47.29% | 23.84% | 1.984 | 71.12% | (49.8, 25.4, 1.96, 75.2) |
| 2 | 52.33% | 18.22% | 2.872 | 70.54% | (58.1, 18.2, 3.19, 76.4) |
| 3 | 52.13% | 18.60% | 2.802 | 70.74% | (59.9, 16.3, 3.68, 76.2) |
| 4 | 54.65% | 16.47% | 3.318 | 71.12% | (61.4, 14.7, 4.17, 76.2) |
| 5 | 58.91% | 11.82% | 4.984 | 70.74% | (65.3, 10.7, 6.13, 76.0) |
| 6 | 61.24% | 9.88% | 6.196 | 71.12% | (66.9, 8.5, 7.84, 75.4) |

## Runtime and completeness

{
  "phase": "full",
  "complete": true,
  "completed": 3096,
  "expected": 3096,
  "technical_failures": 0,
  "parse_failures": 1,
  "length_finishes": 0,
  "seconds_per_request": 2.8922847708950887,
  "full_run_hours_at_measured_rate": 2.487364902969776
}

## Differences from original environment

- Apple MPS/Transformers instead of CUDA/vLLM 0.7.3
- BF16 hardware numerics and sampling RNG differ
- Explicit stable per-request seeds; original run seeds not documented
- Safe literal parsing instead of upstream eval fallback; invalid calls retained as failures
- Original publication checkpoint revision unknown; current official revision frozen

## Comparison

Edited-tool CUR exceeds original-tool CUR in 6/6 cue conditions.
The table below reports local minus paper values in percentage points. A single run and a backend change do not establish statistical equivalence.

| cue | edited CUR delta (pp) | original CUR delta (pp) | CR delta (pp) |
|---|---:|---:|---:|
| 1 | -2.51 | -1.56 | -4.08 |
| 2 | -5.77 | +0.02 | -5.86 |
| 3 | -7.77 | +2.30 | -5.46 |
| 4 | -6.75 | +1.77 | -5.08 |
| 5 | -6.39 | +1.12 | -5.26 |
| 6 | -5.66 | +1.38 | -4.28 |

Position effects are reported separately in results_by_order.csv; each order has 258 cases per cue. CUR values can overlap because both tools may be correctly used in one response.

Paper reference: https://aclanthology.org/2025.emnlp-main.1060.pdf (Table 3).
Environment: transformers-mps; dtype bfloat16; checkpoint revision a09a35458c702b33eeacc393d103063234e8bc28.

## Replay

Run the saved replay command from LOCAL_BASELINE_README.md. Replays use raw_responses.jsonl and do not load a model.

The smoke subset is length-stratified and is not an estimate of full-dataset accuracy.
