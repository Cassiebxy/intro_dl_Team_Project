# Table 3 baseline｜Part 3 / Part 4交接包

**先交Part3独立评分复核，再由Part4整合midterm。** 本包已准备他们所需的输入、原始输出、score、summary、论文对照、失败例、图和便携重放入口，不需要重新跑模型。仅本地生成，等待用户查看；尚未上传GitHub。

## 先看哪两个文件
- [Part 3：评分与验证交接](PART3_SCORING_VALIDATION_HANDOVER_ZH.md)：口径、phantom/alias、角色/顺序、唯一解析失败、离线重放、抽查与签收。
- [Part 4：论文对照与midterm整合](PART4_PAPER_COMPARISON_MIDTERM_HANDOVER_ZH.md)：六行结果、顺序限制、英文写作素材、4–5页组织建议和全组待办。
- [Midterm rubric逐项清单](MIDTERM_RUBRIC_CHECKLIST_ZH.md)：逐行对应用户截图，明确现有证据和待补项。

## 已核实的交付状态
- 258案例×6cue×2顺序=**3096次真实推理**，2026-10-20 15:47 EDT完成。
- 技术故障0，输出截断0，解析失败1保留分母；逐例自动评分和离线重放已完成。
- pooled六组均edited CUR>original；但original-first前三组不满足该方向，必须保留order分析。
- normalizer训练、split/held-out-style协议、router效果及独立多seed复现未完成。本包不宣称这些成果。
- 队友Part3独立签收、Part4最终报告/实际分工确认仍待完成。

## 文件导航
| 目录/文件 | 给谁/用途 |
|---|---|
| tables/per_case_scores.csv | Part3：3096行便于筛选的逐例score |
| tables/paper_vs_local_table3.csv | Part4：六行论文vs本地完整精度和差值 |
| tables/order_effects.csv、ORDER_EFFECTS.md | 两顺序分解及强位置/标签不对称 |
| tables/response_failure_counts.csv、PARSER_FAILURE_CASE.md | 失败统计、原始解析失败与处理口径 |
| tables/REPRESENTATIVE_CASES_ZH.md、representative_cases.jsonl | 成功/失败及同case顺序变化证据 |
| figures/ | 可直接放报告的PNG/PDF对照图、可编辑方法图素材；数据均在tables |
| evidence/run_snapshot/ | 原始输入、prompt、raw response、score、日志、配置和hash，不修改 |
| evidence/reference_upstream/、model_metadata/ | 固定来源和小型模型metadata；无模型权重 |
| evidence/rubric/ | 用户3张评分截图来源记录；可见内容已转写到rubric清单 |
| scripts/verify_and_replay.py | Python标准库即可重放，不依赖原电脑绝对路径 |
| code/ | 原评分/runner源码、历史测试及依赖锁；不是此次自动发布的代码 |
| DATA_DICTIONARY_ZH.md | 字段单位、0–1/百分比/pp区别及status含义 |
| MANIFEST.json、validation/ | 固定文件SHA256、自动完整性/重放核验结果；队友签收另填 |
| REFERENCES.bib、SOURCES_AND_ATTRIBUTION.md | 已核对的引用、来源和发布边界 |

## 你查看时的建议顺序
1. 两份交接文和rubric清单。
2. 主结果表及order图，确认能接受目前结论措辞和局限。
3. 唯一解析失败的处理，以及Part3/Part4签收任务是否明确。
4. 决定之后哪些文档、图、代码或原始证据上传GitHub；这次没有上传。

## 队友离线验收（不训练、不推理、不联网）
在此文件夹执行：
```sh
python3 -B -X utf8 -S scripts/verify_and_replay.py
```
输出在validation/replay/。MANIFEST不包含自身及validation动态输出；它保护固定证据和交接文件。解压后可移动文件夹，原protocol中的绝对路径只是原机provenance，便携脚本使用本包相对路径。

Windows若命令名为`python`，请换用`python -B -X utf8 -S scripts/verify_and_replay.py`。保留UTF-8选项以保证跨系统读取一致。
