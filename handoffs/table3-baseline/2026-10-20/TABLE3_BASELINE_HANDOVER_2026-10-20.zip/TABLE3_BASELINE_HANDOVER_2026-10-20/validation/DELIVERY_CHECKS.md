# Delivery checks — 2026-10-20

- Original project suite rerun: 54 passed in7.93s. No model inference or training during handover preparation.
- Portable Python standard-library replay:3096 unique IDs,12conditions×258,6cue denominators516; every archived per-request score and summary reproduced.
- Cross-check:3034nonempty model-call outputs equal the pinned official dup checker;6manual metric truth-table cases pass.
- All fixed-file manifest hashes and frozen source/input/prompt/code hashes verified. Dynamic validation outputs excluded from MANIFEST by design.
- Independent reviewer checked 3096flat CSV rows, pooled integer counts,12order results and failure categories; no important scoring/reporting issue found. Fixed cross-platform UTF-8 command requirement and added Python version/MANIFEST hash to verification JSON.
- Two PNG figures visually inspected; legends moved outside plotting area to avoid overlap; both have matching vector PDFs and regeneration source.
- Main handover Markdown relative links checked; no broken targets.
- Rubric original screenshot files absent at provided Desktop paths; readable chat images manually transcribed with a source note, without claiming originals are bundled.
- Teammate independent signoff remains PENDING. No GitHub/Drive upload or remote modification during this task.
